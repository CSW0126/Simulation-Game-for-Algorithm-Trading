export { default as Dashboard } from './Dashboard';
export { default as GameInit } from './GameInit';
export { default as History } from './History';
export { default as Profile } from './Profile'
export { default as LeaderBoard } from './LeaderBoard'