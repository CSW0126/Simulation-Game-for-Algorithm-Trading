import React from 'react'

const RandomForm = () => {
  return (
    <div>RandomForm</div>
  )
}

export default RandomForm